<?php
require 'config.php';
if(empty($_SESSION['cLogin'])) {
	header("Location: login.php");
	exit;
}
require 'classes/usuarios.class.php';
$a = new Usuarios();

if(isset($_GET['id']) && !empty($_GET['id'])) {
	$id = $a->excluirFotoPerfil($_GET['id']);
}

if(isset($id)) {
	header("Location: perfil.php?id=".$id);
} else {
	header("Location: anuncio.php");
}