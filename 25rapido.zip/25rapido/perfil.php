<?php require 'pages/header-cliente.php'; ?>
<?php
if (empty($_SESSION['cLogin'])) {
    ?>
    <script type="text/javascript">
        window.location.href = "login.php";
    </script>
    <?php
    exit;
}
?>
<?php
require 'classes/usuarios.class.php';
$u = new Usuarios();


if (isset($_POST['email']) && !empty($_POST['email'])) {
    $email = addslashes($_POST['email']);
    $cep = addslashes($_POST['cep']);
    $endereco = addslashes($_POST['endereco']);
    $numero = addslashes($_POST['numero']);
    $bairro = addslashes($_POST['bairro']);
    $cidade = addslashes($_POST['cidade']);
    $estado = addslashes($_POST['estado']);
    $telefone = addslashes($_POST['telefone']);
    if (isset($_FILES['fotos'])) {
        $fotos = $_FILES['fotos'];
    } else {
        $fotos = array();
    }


    $u->editCadastro($email, $cep, $endereco, $numero, $bairro, $cidade, $estado, $telefone, $fotos, $_GET['id']);

    ?>

    <script language="javascript">
        swal({
            icon: "success",
            title: "Anuncio editado com sucesso!",
            showConfirmButton: true,
            confirmButtonText: "Voltar",
            closeOnConfirm: false
        }).then(function(result) {
            window.location = "perfil.php?id=<?php echo $_SESSION['cLogin']; ?>";
        })
    </script>
<?php
}
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $info = $u->getMeuscadastro($_GET['id']);
} else {

    ?>
    <script type="text/javascript">
        window.location.href = "anuncio.php";
    </script>
    <?php
    exit;
}


?>
<!-- End popular-post Area -->

<!-- Start feature-cat Area -->
<section class="post-area mt-5 ">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="panel-body">
                    <h3>FOTO</h3>

                    <?php

                    $fotoperf = $u->getCadfoto();

                    foreach ($fotoperf as $fotosperf) :
                        ?>
                    <?php endforeach; ?>
                    <div class="thumb mt-3">
                        <div class="panel-body">
                            <?php if (!empty($fotosperf['url'])) : ?>
                                <div class="foto_item">
                                    <img src="img/avata/<?php echo $fotosperf['url']; ?>" width="180" height="180" class="img-thumbnail" alt="">
                                </div>
                            <?php else : ?>
                                <div class="foto_item">
                                    <img src="img/avata/default.png" width="180" height="180" class="img-thumbnail" alt="">
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php foreach ($info['fotos'] as $foto) : ?>

                        <a href="exclufotoperf.php?id=<?php echo $foto['id']; ?>" class="genric-btn  radius mt-1" style="border: 2px solid #eee; width: 176px; font-size: 14px;" onclick="myFunction()">Excluir imagem</a>

                    <?php endforeach; ?>


                </div>


                <p class="genric-btn  radius mt-5" style="border: 2px solid #eee; width: 176px; font-size: 14px;"><?php echo $info['nome']; ?></p>

                <p class="genric-btn radius" style="border: 2px solid #eee; width: 176px; font-size: 12px;">CPF: <?php echo $info['cpf']; ?></p>


            </div>
            <div class="col-md-7 mt-sm-20">
                <form method="POST" enctype="multipart/form-data">
                    <div class="mt-10">
                        <label for="endereco">E-mail:</label>
                        <input type="text" name="email" value="<?php echo $info['email']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10">
                        <label for="endereco">CEP</label>
                        <input type="text" name="cep" value="<?php echo $info['cep']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10">
                        <label for="endereco">Endereco</label>
                        <input type="text" name="endereco" value="<?php echo $info['endereco']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10">
                        <label for="numero">Numero</label>
                        <input type="text" name="numero" value="<?php echo $info['numero']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10">
                        <label for="bairro">Bairro</label>
                        <input type="text" name="bairro" value="<?php echo $info['bairro']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10">
                        <label for="cidade">Cidade</label>
                        <input type="text" name="cidade" value="<?php echo $info['cidade']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10">
                        <label for="estado">Estado</label>
                        <input type="text" name="estado" value="<?php echo $info['estado']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10">
                        <label for="telefone">Telefone</label>
                        <input type="text" name="telefone" value="<?php echo $info['telefone']; ?>" placeholder="Telefone" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Primary color'" required class="single-input-primary">
                    </div>
                    <div class="mt-10 file">
                        <input type="file" name="fotos[]" placeholder="Telefone" class="inputfile">

                    </div>
                    <button type="submit" class="genric-btn primary e-large mt-10">Salvar</button>
                </form>

            </div>

        </div>


        <div class="section-top-border mt-9">
        </div>

    </div>
</section>
<!-- End feature-cat Area -->

<!-- Start post Area -->


<!-- Start download Area -->
<!-- Start popular-post Area -->
<section class="popular-post-area pt-10">

    <div class="container">
        <div class="row align-items-center">

            <div class="menu-content pb-60 col-lg-12">
                <div class="title text-center">
                    <h1 class="mb-10">Avaliações</h1>
                    <!-- <p></p> -->
                </div>
            </div>

            <div class="active-popular-post-carusel">
                <div class="single-popular-post d-flex flex-row">
                    <div class="thumb">
                        <img class="img-fluid" src="img/p1.png" alt="">

                    </div>
                    <div class="details">
                        <a href="#">
                            <h4>Creative Designer</h4>
                        </a>
                        <h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
                            ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
                        </p>
                    </div>
                </div>
                <div class="single-popular-post d-flex flex-row">
                    <div class="thumb">
                        <img src="img/p2.png" alt="">
                    </div>
                    <div class="details">
                        <a href="#">
                            <h4>Creative Designer</h4>
                        </a>
                        <h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
                            ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
                        </p>
                    </div>
                </div>
                <div class="single-popular-post d-flex flex-row">
                    <div class="thumb">
                        <img src="img/p1.png" alt="">
                    </div>
                    <div class="details">
                        <a href="#">
                            <h4>Creative Designer</h4>
                        </a>
                        <h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
                            ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
                        </p>
                    </div>
                </div>
                <div class="single-popular-post d-flex flex-row">
                    <div class="thumb">
                        <img src="img/p2.png" alt="">
                    </div>
                    <div class="details">
                        <a href="#">
                            <h4>Creative Designer</h4>
                        </a>
                        <h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
                            ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
                        </p>
                    </div>
                </div>
                <div class="single-popular-post d-flex flex-row">
                    <div class="thumb">
                        <img src="img/p1.png" alt=""> <br>
                        <p style="color:#fff;">25rapido</p>
                    </div>
                    <div class="details">
                        <a href="#">
                            <h4>Creative Designer</h4>
                        </a>
                        <h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
                            ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
                        </p>
                    </div>
                </div>
                <div class="single-popular-post d-flex flex-row">
                    <div class="thumb">
                        <img src="img/p2.png" alt="">
                        <p>asdadasasdasd</p>
                    </div>
                    <div class="details">
                        <a href="#">
                            <h4>Creative Designer</h4>
                        </a>
                        <h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
                            ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- End post Area -->
<!-- End download Area -->

<?php include("pages/footer.php"); ?>