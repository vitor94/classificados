<?php include("pages/header.php"); ?>
<?php
require 'classes/anuncios.class.php';
require 'classes/cadastros.class.php';
require 'classes/categorias.class.php';
require 'classes/usuarios.class.php';
$a = new Anuncios();
$c = new Categorias();
$i = new infocad();
$u = new Usuarios();

$filtros = array(
	'categoria' => '',
	'cidade' => '',
	'bairro' => ''
);
if (isset($_GET['filtros'])) {
	$filtros = $_GET['filtros'];
}
$anunciosindex = $a->getUltimosAnunciosIndex($filtros);
$info = $i->getListaCad();
$categorias = $c->getLista();
$total_usuarios = $u->getTotalUsuarios();

?>

<!-- start banner Area -->
<section class="banner-area relative" id="home">
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row fullscreen d-flex align-items-center justify-content-center">
			<div class="banner-content col-lg-12">
				<h1 class="text-white">
					<!-- <span>1500+</span> -->Encontre aqui profissionais em sua Região!
				</h1>
				<form action="anunciosbsc.php" class="serach-form-area">
					<div class="row justify-content-center form-wrap">
						<div class="col-lg-4 form-cols">
							<select name="filtros[categoria]" class="form-control">
								<option>Qual tio de profissional quer encontrar ?</option>
								<?php foreach ($categorias as $cat) : ?>
									<option value="<?php echo $cat['id']; ?>" <?php echo ($cat['id'] == $filtros['categoria']) ? 'selected="selected"' : ''; ?>>
										<?php echo utf8_encode($cat['nome']); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="col-lg-3 form-cols autocomplete">

							<input type="text" id="myInput" value="<?php echo $filtros['cidade']; ?>" name="filtros[cidade]" autocomplete="off" placeholder="Cidade" class="form-control">

						</div>
						<div class="col-lg-3 form-cols autocomplete">

							<input type="text" id="bairro" value="<?php echo $filtros['bairro']; ?>" name="filtros[bairro]" autocomplete="off" placeholder="Bairro" class="form-control">

						</div>

						<div class="col-lg-2 form-cols">
							<button type="submit" class="btn btn-info">
								<span class="lnr lnr-magnifier"></span> Pesquisar
							</button>
						</div>
					</div>
				</form>
				<p class="text-white" style="font-size: 30px;">Mais de <?php echo $total_usuarios; ?> profissionais cadastrados no 25 rápido.
				</p>
				<p class="text-white mt-4" style="font-size: 30px;">VOCÊ É UM PROFISSIONAL?</p><br>
				<a href="cadastrar.php" class="btn btn-success mt-4" style="border-radius:0; background-color: #fff; border: 0; font-size: 25px; color: chocolate;">
					CADASTRE-SE!</a>
			</div>
		</div>
	</div>
</section>
<!-- End banner Area -->

<!-- Start features Area -->
<section class="features-area">
	<div class="container">

		<div class="row">
			<div class="col-lg-2 col-md-4 col-sm-6">
				<div class="single-fcat">
					<a href="">
						<img src="img/icons8-balde-de-tinta-64.png" width="50" height="50" alt="">
					</a>
					<p>Pintor</p>
				</div>
			</div>
			<div class="col-lg-2 col-md-4 col-sm-6">
				<div class="single-fcat">
					<a href="http://localhost/25rapido/anunciosbsc.php?filtros%5Bcategoria%5D=4&filtros%5Bcidade%5D=&filtros%5Bbairro%5D=">
						<img src="img/icon-colher-pedreiro-azul.png" width="50" height="50" alt="">
					</a>
					<p>Pedreiro</p>
				</div>
			</div>
			<div class="col-lg-2 col-md-4 col-sm-6">
				<div class="single-fcat">
					<a href="category.html">
						<img src="img/icons8-painel-de-comando-64.png" width="50" height="50" alt="">
					</a>
					<p>Eletricista</p>
				</div>
			</div>
			<div class="col-lg-2 col-md-4 col-sm-6">
				<div class="single-fcat">
					<a href="category.html">
						<img src="img/o4.png" width="50" height="50" alt="">
					</a>
					<p>Tecnologia</p>
				</div>
			</div>
			<div class="col-lg-2 col-md-4 col-sm-6">
				<div class="single-fcat">
					<a href="category.html">
						<img src="img/icons8-mecânico-50.png" width="50" height="50" alt="">
					</a>
					<p>Mecânico</p>
				</div>
			</div>
			<div class="col-lg-2 col-md-4 col-sm-6">
				<div class="single-fcat">
					<a href="category.html">
						<img src="img/icons8-encanador-50.png" width="50" height="50" alt="">
					</a>
					<p>Encanador</p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End features Area -->

<!-- End popular-post Area -->

<!-- Start feature-cat Area -->
<section class="price-area section-gap" id="price">
	<div class="container">
		<div class="menu-content pb-60 col-lg-12">
			<div class="title text-center">
				<h1 class="mb-10">Destaques</h1>
				<!-- <p></p> -->
			</div>
		</div>
		<div class="row">
			<?php foreach ($anunciosindex as $anunciosind) : ?>
				<div class="col-lg-4  mt-4">
					<div class="single-price no-padding">
						<div class="price-top">
							<div class="thumb">
								<?php if (!empty($anunciosind['url'])) : ?>
									<img src="img/anuncios/<?php echo $anunciosind['url']; ?>" width="310" height="160" alt="">
								<?php else : ?>
									<img src="img/anuncios/default.jpg" width="310" height="160" alt="">
								<?php endif; ?>
							</div>
							<a href="perf-anuncio.php?id=<?php echo $anunciosind['id']; ?>">
								<h4 class="mt-4"><?php echo $anunciosind['titulo']; ?></h4>
							</a>
						</div>
						<h6 class="genric-btn default" style="color: #f87416; width:100%; padding:10px; font-size:13px;"><?php echo utf8_encode($anunciosind['categoria']); ?></h6>
						<p class="mt-3" style="padding:15px;">
							<?php echo substr($anunciosind['descricao'], 0, 100), ' ', '[...]'; ?>
						</p>
						<p class="mt-2" style="padding:15px;">
							<h4>LOCALIZAÇÃO</h4><br>
							<span class="badge badge-dark" style="padding:5px;"><?php echo $anunciosind['cidade']; ?></span><br>
							<span class="badge badge-dark" style="padding:5px;"><?php echo $anunciosind['bairro']; ?></span>
						</p>
						<ul class="btns" style="">
							<li><a href="" style="border: 1px solid #eee; width:65%;" class="genric-btn default radius"><span class="lnr lnr-thumbs-up"></span> Avaliar</a></li>
							<li><a href="" style="border: 1px solid #eee; width:65%;" class="genric-btn default radius mt-2"><span class="lnr lnr-phone-handset"></span> Ver Telefone</a></li>
						</ul><br>

					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<!-- End feature-cat Area -->

<!-- Start post Area -->


<div class="mt-5"></div>
<!-- Start callto-action Area -->
<section class="callto-action-area section-gap" id="join">
	<div class="container">
		<div class="row d-flex justify-content-center">
			<div class="menu-content col-lg-9">
				<div class="title text-center">
					<h1 class="mb-10 text-white">Como Funciona</h1>
					<p class="text-white mt-5">O 25 Rápido é uma plataforma simples e direta para quem precisa encontrar profissionais especializados. O nosso mecanismo de geolocalização permite conectar, por proximidade, profissionais e clientes em busca de seus serviços.

						Nosso objetivo é simplificar, ao máximo, a busca de profissionais especializados para você que precisa resolver problemas do seu dia-a-dia. Para o profissional, o 25 Rápido disponibiliza uma plataforma operacional simples e dinâmica, que permite o anúncio de seus serviços de forma customizada e direta.

						Somos uma ferramenta 100% idealizada para aproximar pessoas que precisam de soluções para os seus problemas e profissionais com expertise para resolvê-las.

					</p>
					<a class="primary-btn" href="#">Buscar Serviços</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End calto-action Area -->

<!-- Start download Area -->
<!-- Start popular-post Area -->
<section class="popular-post-area pt-100">

	<div class="container">
		<div class="row align-items-center">

			<div class="menu-content pb-60 col-lg-12">
				<div class="title text-center">
					<h1 class="mb-10">Avaliações</h1>
					<!-- <p></p> -->
				</div>
			</div>

			<div class="active-popular-post-carusel">
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img class="img-fluid" src="img/p1.png" alt="">

					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p2.png" alt="">
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p1.png" alt="">
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p2.png" alt="">
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p1.png" alt=""> <br>
						<p style="color:#fff;">25rapido</p>
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p2.png" alt="">
						<p>asdadasasdasd</p>
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- End post Area -->
<!-- End download Area -->

<?php include("pages/footer.php"); ?>