<?php
class comentarios {

    public function addComent($nome, $email, $msg){
        global $pdo;

        $sql = $pdo->prepare("INSERT INTO comentarios SET id = :id, nome = :nome, email = :email, msg = :msg, data_msg = NOW()");
        $sql->bindValue(":nome", $nome);
        $sql->bindValue(":email", $email);
        $sql->bindValue(":msg", $msg);
        $sql->bindValue(":id", $_SESSION['cLogin']);
        $sql->execute();
    }

    public function getComent(){
        global $pdo;

        $array = array();
        $sql = $pdo->prepare("SELECT *,(select comentarios.msg from comentarios where comentarios.id_coment = anuncios.id_usuario limit 1) as msg FROM anuncios where id = :id
        ");
        $sql->bindValue(":id", $_SESSION['cLoginUser']);
        $sql->execute();

        
        if($sql->rowCount() > 0) {
            $array = $sql->fetchAll();
        }
        return $array;
    }


   
}
