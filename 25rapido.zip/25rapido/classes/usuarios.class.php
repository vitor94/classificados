<?php
class Usuarios{
    private $id;
    private $status;

    public function cadastrar($nome, $email, $cep, $endereco, $numero, $bairro, $cidade, $estado, $telefone, $cpf, $senha, $termos)
    {
        global $pdo;
        $sql = $pdo->prepare("SELECT id FROM usuarios WHERE email = :email, cpf = :cpf");
        $sql->bindValue(":email", $email);
        $sql->bindValue(":cpf", $cpf);
        $sql->execute();

        if ($sql->rowCount() == 0) { 

            $sql = $pdo->prepare("INSERT INTO usuarios SET nome = :nome, email = :email, cep = :cep, endereco = :endereco, numero = :numero,
            bairro = :bairro, cidade = :cidade, estado = :estado, telefone = :telefone, cpf = :cpf, senha = :senha, termos = :termos, status = :status");
            $sql->bindValue(":nome", $nome);
            $sql->bindValue(":email", $email);
            $sql->bindValue(":cep", $cep);
            $sql->bindValue(":endereco", $endereco);
            $sql->bindValue(":numero", $numero);
            $sql->bindValue(":bairro", $bairro);
            $sql->bindValue(":cidade", $cidade);
            $sql->bindValue(":estado", $estado);
            $sql->bindValue(":telefone", $telefone);
            $sql->bindValue(":cpf", $cpf);
            $sql->bindValue(":senha", md5($senha));
            $sql->bindValue(":termos", $termos);
            $sql-> bindValue(":status", '0');
            $sql->execute();

            return true;
    }else{
            return false;
        }
    }

    public function getCadfoto(){
        global $pdo;

        $array = array();
        $sql = $pdo->prepare("SELECT *,(select avatar.url from avatar where avatar.id_foto = usuarios.id limit 1)as url FROM usuarios where id = :id");
        $sql->bindValue(":id", $_SESSION['cLogin']);
        $sql->execute();

        
        if($sql->rowCount() > 0) {
            $array = $sql->fetchAll();
        }
        return $array;
    }


    public function setUsuario($id){
        global $pdo;

        $this->id = $id;

        $sql = $pdo->prepare("SELECT * FROM  usuarios WHERE id = :id");
        $sql->bindValue(":id", $id);
        $sql->execute();

        if($sql->rowCount() > 0) {
            $sql = $sql->fetch();
            $this->status = $sql['status'];
        }


    }

    public function getStatus(){
        return $this->status;
    }
   
   
    public function temStatus($p){
        if($p = $this->status){
            return true;
        }else{
            return false;
        }
    }
  
   
    public function getMeuscadastro($id){
        $array = array();
        global $pdo;

        $sql = $pdo->prepare("SELECT * FROM usuarios WHERE id = :id");
        $sql->bindValue(":id", $id);
        $sql->execute();

        if($sql->rowCount() > 0){
            $array = $sql->fetch();
            $array['fotos'] = array();

            $sql = $pdo->prepare("SELECT id,url FROM avatar WHERE id_foto = :id_foto limit 1");
            $sql->bindValue(":id_foto", $id);
            $sql->execute();

            if($sql->rowCount() >= 1){
                $array['fotos'] = $sql->fetchAll();
            }
        }
        return $array;
    }





    public function login($email, $senha) {
        global $pdo;

        $sql = $pdo->prepare("SELECT id FROM usuarios WHERE email = :email AND senha = :senha");
        $sql->bindValue(":email", $email);
        $sql->bindValue(":senha", md5($senha));
        $sql->execute();

        if($sql->rowCount() > 0) {
            $dado = $sql->fetch();
            $_SESSION['cLogin'] =$dado['id'];
        
    

        return true;
    }else{
        return false;
    }
   
    }


    public function loginUser($cpf, $senha) {
        global $pdo;

        $sql = $pdo->prepare("SELECT id FROM userav WHERE cpf = :cpf AND senha = :senha");
        $sql->bindValue(":cpf", $cpf);
        $sql->bindValue(":senha", md5($senha));
        $sql->execute();

        if($sql->rowCount() > 0) {
            $dado = $sql->fetch();
            $_SESSION['cLoginUser'] = $dado['id'];

        return true;
    }else{
        return false;
    }
   
    }

    public function editCadastro($email, $cep, $endereco, $numero, $bairro, $cidade, $estado, $telefone, $fotos, $id){
        global $pdo;

        $sql = $pdo->prepare("UPDATE usuarios SET email = :email, cep = :cep, endereco = :endereco, numero = :numero, bairro = :bairro,
        cidade = :cidade, estado = :estado, telefone = :telefone, WHERE id = :id");
        $sql->bindValue(":email", $email);
        $sql->bindValue(":cep", $cep);
        $sql->bindValue(":endereco", $endereco);
        $sql->bindValue(":numero", $numero);
        $sql->bindValue(":bairro", $bairro);
        $sql->bindValue(":cidade", $cidade);
        $sql->bindValue(":estado", $estado);
        $sql->bindValue(":telefone", $telefone);
        $sql->bindValue("id", $id);
        $sql->execute();

        if(count($fotos) > 0) {
            for($q=0;$q<count($fotos['tmp_name']);$q++) {
                $tipo = $fotos['type'][$q];
                if(in_array($tipo, array('image/jpeg', 'image/png'))){
                    $tmpname = md5(time().rand(0,9999)).'.jpg';
                    move_uploaded_file($fotos['tmp_name'][$q], 'img/avata/'.$tmpname);

                    list($width_orig, $height_orig) = getimagesize('img/avata/'.$tmpname);
                    $ratio = $width_orig/$height_orig;

                    $width = 500;
                    $height = 500;

                    if($width/$height > $ratio){
                        $width = $height*$ratio;
                    }else{
                        $height = $width/$ratio;
                    }

                    $img = imagecreatetruecolor($width,  $height);
                    if($tipo == 'image/jpeg'){
                        $origi = imagecreatefromjpeg('img/avata/'.$tmpname);
                    }elseif($tipo == 'image/png') {
                        $origi = imagecreatefrompng('img/avata/'.$tmpname);
                    }

                    imagecopyresampled($img, $origi, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
                    imagejpeg($img, 'img/avata/'.$tmpname, 80);


                    $sql = $pdo->prepare("INSERT INTO avatar SET id_foto = :id_foto, url = :url");
                    $sql->bindValue(":id_foto", $id);
                    $sql->bindValue(":url", $tmpname);
                    $sql->execute();

                }
            }
        }

    }

    public function excluirFotoPerfil($id){
        global $pdo;
        $id_foto = 0;

		$sql = $pdo->prepare("SELECT * FROM avatar WHERE id = :id");
		$sql->bindValue(":id", $id);
		$sql->execute();

		if($sql->rowCount() > 0) {
			$row = $sql->fetch();
            $id_foto = $row['id_foto'];
            if(is_file("img/avata/" .$row['url'])){
                unlink("img/avata/".$row['url']);
            }
		}

		$sql = $pdo->prepare("DELETE FROM avatar WHERE id = :id");
		$sql->bindValue(":id", $id);
		$sql->execute();

		return $id_foto;

    }

    public function getTotalUsuarios(){
        global $pdo;

        $sql = $pdo->query("SELECT COUNT(*) as c FROM usuarios");
        $row = $sql->fetch();

        return $row['c'];
    }


    

    // public function esquecisenha($email){
    //     global $pdo;

    //     $sql = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email");
    //     $sql->bindValule(":email", $email);
    //     $sql-execure();

    //     if($sql->rowCount() > 0){

    //         $sql = $sql->fetch();
    //         $id = $sql['id'];
    //     }

    // }

}
