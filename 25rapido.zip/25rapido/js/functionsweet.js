document.getElementById('b1').onclick = function(){
	swal("Here's a message!");
};