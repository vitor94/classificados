<?php include("pages/header.php"); ?>
<?php
require 'classes/anuncios.class.php';
require 'classes/categorias.class.php';
$a = new Anuncios();
$c = new Categorias();

$filtros = array(
	'categoria' => '',
	'cidade' => '',
	'bairro' => ''
);
if (isset($_GET['filtros'])) {
	$filtros = $_GET['filtros'];
}

$total_anuncios = $a->getTotalAnuncios($filtros);

$p = 1;
if (isset($_GET['p']) && !empty($_GET['p'])) {
	$p = addslashes($_GET['p']);
}
$por_pagina = 9;
$total_paginas = ceil($total_anuncios / $por_pagina);

$anuncios = $a->getUltimosAnuncios($p, $por_pagina, $filtros);

$categorias = $c->getLista();

?>

<!-- start banner Area -->
<section class="banner-area relative" id="home" style="height:26rem;">
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row fullscreen d-flex align-items-center justify-content-center">
			<div class="banner-content col-lg-12">
				<h1 class="text-white">
					<!-- <span>1500+</span> -->Encontre aqui profissionais de confiança em sua Região!
				</h1>
				<form method="GET" class="serach-form-area" autocomplete="off">
					<div class="row justify-content-center form-wrap">
						<div class="col-lg-3 form-cols">
							<select name="filtros[categoria]" class="form-control">
								<option>Seleciona Categoria</option>
								<?php foreach ($categorias as $cat) : ?>
									<option value="<?php echo $cat['id']; ?>" <?php echo ($cat['id'] == $filtros['categoria']) ? 'selected="selected"' : ''; ?>>
										<?php echo utf8_encode($cat['nome']); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="col-lg-3 form-cols autocomplete">

							<input type="text" id="myInput" value="<?php echo $filtros['cidade']; ?>" name="filtros[cidade]" autocomplete="off" placeholder="Cidade" class="form-control">

						</div>
						<div class="col-lg-3 form-cols autocomplete">

							<input type="text" id="bairro" value="<?php echo $filtros['bairro']; ?>" name="filtros[bairro]" autocomplete="off" placeholder="Bairro" class="form-control">

						</div>

						<div class="col-lg-2 form-cols">
							<button type="submit" class="btn btn-info">
								<span class="lnr lnr-magnifier"></span> Pesquisar
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>
<!-- End banner Area -->


<!-- End popular-post Area -->

<!-- Start feature-cat Area -->
<section class="price-area section-gap" id="price">
	<div class="container">
		<div class="menu-content pb-60 col-lg-12">
			<div class="title text-center">
				<h1 class="mb-10">Anuncios</h1>
				<!-- <p></p> -->
			</div>
		</div>
		<h3>Total de Anuncios <span class="badge badge-danger"><?php echo $total_anuncios; ?></span></h3>
		<?php if ($total_anuncios == 0) {
			echo "<h4 class='mt-5'>Sua pesquisa não obteve nenhum resultado!</h4>";
			echo "<h6 class='mt-3'> Sugestões:</h6>";
			echo "<li class= 'mt-4'>Assegure-se de que todas as palavras estejam escritas corretamente.</li>";
			echo "<li class= 'mt-1'>Tente palavras diferentes.</li>";
			echo "<li class= 'mt-1'>Tente frases mais comuns</li>";
			echo "<li class= 'mt-1'>Tenta com menos palavras.</li>";
		} ?>
		<div class="row">
			<?php foreach ($anuncios as $anuncio) : ?>
				<div class="col-lg-4  mt-4">
					<div class="single-price no-padding">
						<div class="price-top">
							<div class="thumb">
								<?php if (!empty($anuncio['url'])) : ?>
									<img src="img/anuncios/<?php echo $anuncio['url']; ?>" width="310" height="160" alt="">
								<?php else : ?>
									<img src="img/anuncios/default.jpg" width="310" height="160" alt="">
								<?php endif; ?>
							</div>
							<a href="perf-anuncio.php?id=<?php echo $anuncio['id']; ?>">
								<h4 class="mt-4"><?php echo $anuncio['titulo']; ?></h4>
							</a>
						</div>
						<h6 class="genric-btn default" style="color: #f87416; width:100%; padding:10px; font-size:13px;"><?php echo utf8_encode($anuncio['categoria']); ?></h6>
						<p class="mt-3" style="padding:15px;">
							<?php echo substr($anuncio['descricao'], 0, 100), ' ', '[...]'; ?>
						</p>
						<p class="mt-2" style="padding:15px;">
							<h4>LOCALIZAÇÃO</h4><br>
							<span class="badge badge-dark" style="padding:5px;"><?php echo $anuncio['cidade']; ?></span><br>
							<span class="badge badge-dark" style="padding:5px;"><?php echo $anuncio['bairro']; ?></span>
						</p>
						<ul class="btns" style="">
							<li><a href="" style="border: 1px solid #eee; width:65%;" class="genric-btn default radius"><span class="lnr lnr-thumbs-up"></span> Avaliar</a></li>
							<li><a href="" style="border: 1px solid #eee; width:65%;" class="genric-btn default radius mt-2"><span class="lnr lnr-phone-handset"></span> Ver Telefone</a></li>
						</ul><br>

					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<nav aria-label="...">
			<ul class="pagination pagination-sm mt-5">
				<?php for ($q = 1; $q <= $total_paginas; $q++) : ?>
					<li class="page-item disabled" style="padding: 5px;">
						<a class="<?php echo ($p == $q) ? 'ticker-btnpg' : 'ticker-btn'; ?>" style="color= #000;" href="anunciosbsc.php?<?php
																																	$w = $_GET;
																																	$w['p'] = $q;
																																	echo http_build_query($w);
																																	?>"><?php echo $q; ?></a>
					</li>
				<?php endfor; ?>
			</ul>
		</nav>
	</div>
</section>
<!-- End feature-cat Area -->

<!-- Start post Area -->


<div class="mt-5"></div>
<!-- Start callto-action Area -->
<section class="callto-action-area section-gap" id="join">
	<div class="container">
		<div class="row d-flex justify-content-center">
			<div class="menu-content col-lg-9">
				<div class="title text-center">
					<h1 class="mb-10 text-white">Como Funciona</h1>
					<p class="text-white mt-5">O 25 Rápido é uma plataforma simples e direta para quem precisa encontrar profissionais especializados. O nosso mecanismo de geolocalização permite conectar, por proximidade, profissionais e clientes em busca de seus serviços.

						Nosso objetivo é simplificar, ao máximo, a busca de profissionais especializados para você que precisa resolver problemas do seu dia-a-dia. Para o profissional, o 25 Rápido disponibiliza uma plataforma operacional simples e dinâmica, que permite o anúncio de seus serviços de forma customizada e direta.

						Somos uma ferramenta 100% idealizada para aproximar pessoas que precisam de soluções para os seus problemas e profissionais com expertise para resolvê-las.

					</p>
					<a class="primary-btn" href="#">Buscar Serviços</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- End calto-action Area -->

<!-- Start download Area -->
<!-- Start popular-post Area -->
<section class="popular-post-area pt-100">

	<div class="container">
		<div class="row align-items-center">

			<div class="menu-content pb-60 col-lg-12">
				<div class="title text-center">
					<h1 class="mb-10">Avaliações</h1>
					<!-- <p></p> -->
				</div>
			</div>

			<div class="active-popular-post-carusel">
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img class="img-fluid" src="img/p1.png" alt="">

					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p2.png" alt="">
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p1.png" alt="">
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p2.png" alt="">
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p1.png" alt=""> <br>
						<p style="color:#fff;">25rapido</p>
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
				<div class="single-popular-post d-flex flex-row">
					<div class="thumb">
						<img src="img/p2.png" alt="">
						<p>asdadasasdasd</p>
					</div>
					<div class="details">
						<a href="#">
							<h4>Creative Designer</h4>
						</a>
						<h6>&#9733;&#9733;&#9733;&#9733;&#9733;</h6>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temporinc
							ididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis.
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- End post Area -->
<!-- End download Area -->

<?php include("pages/footer.php"); ?>