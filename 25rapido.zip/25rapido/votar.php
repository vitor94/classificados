<?php 
 require 'config.php';

 

 if(!empty($_GET['id']) && !empty($_GET['voto'])){
     $id = intval($_GET['id']);
     $voto = intval($_GET['voto']);

     if($voto >= 1 && $voto <= 5) {

        $sql = $pdo->prepare("INSERT INTO votos SET id_anunciov = :id_anunciov, nota = :nota");
        $sql->bindValue(":id_anunciov", $id);
        $sql->bindValue(":nota", $voto);
        $sql->execute();

        $sql = $pdo->prepare("UPDATE anuncios SET media = (select (SUM(nota)/COUNT(*)) from votos where votos.id_anunciov = anuncios.id) WHERE id = :id");
        $sql->bindValue(":id", $id);
        $sql->execute();

        header("Location: perf-anuncio.php?id=".$id);
        exit;
     
    }
 }

?>