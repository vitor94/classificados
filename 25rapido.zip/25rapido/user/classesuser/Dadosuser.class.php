<?php 

class Dados{

    public function pegarDados($id, $dados){
		global $pdo;

		$id = addslashes($id);

		$sql = $pdo->prepare("SELECT * FROM userav WHERE id = :id");
		$sql->bindValue(":id", $id);
		$sql->execute();
		$dadosUser = $sql->fetch();
		$dados = addslashes($dados);

		return $dadosUser[$dados];
    }
    
   
}
?>