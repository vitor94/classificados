<?php
class UsuariosUser{

        public function cadastrar($nome, $sobrenome, $email, $cpf, $senha,$termos)
        {
        global $pdo;
        $sql = $pdo->prepare("SELECT id FROM userav WHERE email = :email, cpf = :cpf");
        $sql->bindValue(":email", $email);
        $sql->bindValue(":cpf", $cpf);
        $sql->execute();

        if ($sql->rowCount() == 0) { 

            $sql = $pdo->prepare("INSERT INTO userav SET nome = :nome, sobrenome = :sobrenome, email = :email, cpf = :cpf, senha = :senha, termos = :termos");
            $sql->bindValue(":nome", $nome);
            $sql->bindValue(":sobrenome", $sobrenome);
            $sql->bindValue(":email", $email);
            $sql->bindValue(":cpf", $cpf);
            $sql->bindValue(":senha", md5($senha));
            $sql->bindValue(":termos", $termos);
            $sql->execute();

            return true;
    }else{
            return false;
        }
    }


    



}
?>