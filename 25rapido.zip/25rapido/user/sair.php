<?php
session_start();
unset($_SESSION['cLoginUser']);
header("Location: ../");

?>