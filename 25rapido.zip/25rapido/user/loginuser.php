<?php require 'pagesuser/header-cad-login.php'; ?>

<section class="contact-page-area" id="login">
    <div class="container">
        <p class="text-black link-nav"><a href="index.html">Home </a> <span class="lnr lnr-arrow-right" style="color:#000;"></span> Cadastro</p>
        <div class="row  justify-content-center">
            <div class="menu-content pb-60 col-lg-12">
                <div class="title text-center">
                    <h1 class="mb-10">Login</h1>
                    <p></p>
                </div>
            </div>
            <div class="col-lg-8">
                <?php
                require '../classes/usuarios.class.php';
                $u = new Usuarios();

                if (isset($_POST['cpf']) && !empty($_POST['cpf'])) {
                    $cpf = addslashes($_POST['cpf']);
                    $senha = $_POST['senha'];

                    if ($u->loginUser($cpf, $senha)) {
                        ?>
                        <script type="text/javascript">
                            window.location.href = "user.php";
                        </script>
                    <?php
                    } else {
                        ?>
                        <script language="javascript">
                            swal({
                                icon: "warning",
                                title: "ERROR!",
                                text: "CPF ou SENHA incorreto. Favor verificar!",
                                showConfirmButton: true,
                                confirmButtonText: "Voltar",
                                closeOnConfirm: false
                            }).then(function(result) {
                                window.location = "loginuser.php";
                            })
                        </script>
                    <?php
                    }
                }
                ?>
                <form method="post" class="contact-form text-left form-area">
                    <div class="card" style="width: 25rem; margin: 0 auto; float:none;">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Digite seu CPF</label>
                                <input type="text" name="cpf" class="common-input mb-20 form-control" id="exampleInputEmail1" aria-describedby="emailHelp" onkeyup="cpfCheck(this)" onkeydown="javascript: fMasc( this, mCPF );" placeholder="CPF">
                                <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Senha</label>
                                <input type="password" name="senha" class="common-input mb-20 form-control" id="exampleInputPassword1" placeholder="minimo 8 caracteres">
                            </div>
                            <button type="submit" class="genric-btn primary e-large">Entrar</button>
                            <small id="emailHelp" class="form-text text-muted" style="float:right; font-size:14px; padding:10px;"><a href="esqueci.php">Esqueci minha senha.</a></small>
                </form>
            </div>
        </div>
        <!-- <div class="card" style="width: 30rem; margin-left:120px;">
                <div class="card-body">
                    <form method="post" class="contact-form text-right form-area">
                        <div class="row justify-content-md-center">
                            <div class="col-8 form-group " >

                                <input name="nome" id="nome" placeholder="Nome" class="common-input mb-20 form-control" type="text">
                                <input name="email" id="email" placeholder="E-mail" class="common-input mb-20 form-control" type="text">
                                <button type="submit" class="genric-btn primary e-large" style="">CADASTRAR </button>
                            </div>
                           
                                

                        </div>
                    </form>
                </div>
            </div> -->
    </div>
    </div>
    </div>
</section>
<?php include("pagesuser/footer.php"); ?>