<?php include ("pagesuser/header-cliente.php"); ?>
<?php
if (empty($_SESSION['cLoginUser'])) {
	?>
	<script type="text/javascript">
		window.location.href = "user.php";
	</script>
	<?php
	exit;
}
?>
<!-- Start blog-posts Area -->
<section class="post-area mt-5">
	<div class="container">
		<h1>Meus Anuncios</h1>
	
		
			<a href="add-anuncio.php" class="genric-btn default radius mt-5" style="border: 2px solid #eee;">Adicionar Anuncio</a>
	
			<a href="#" class="genric-btn default radius mt-5" onClick="swal('OPS!', 'Para adicionar anuncio é preciso efetuar o pagamento!', 'warning')" style="border: 2px solid #eee;">Adicionar Anuncio</a>
	


		<div class="row justify-content-center d-flex mt-5">
			<div class="col-lg-8 post-list">
			

					<div class="thumb">
					
							<img src="img/anuncios/<?php echo $anuncio['url']; ?>" class="img-thumbnail" alt="">
					
							<img src="img/anuncios/default.jpg" class="img-thumbnail" alt="">
					
					</div>
					<div class="single-post d-flex flex-row">

						<div class="details" style="margin-left:30px;">
							<div class="title d-flex flex-row justify-content-between">
								<div class="titles">
									<a href="single.html">
										<h4></h4>
									</a>
									<h6>Premium Labels Limited</h6>
								</div>

							</div>
							<p>
								
							</p>
							<span class="badge badge-secondary" style="padding:4px; font-size:16px;">Tel: </span>
							<span class="badge badge-secondary" style="padding:4px; font-size:16px;">Caidade: </span>
							<span class="badge badge-secondary" style="padding:4px; font-size:16px;">Bairro: </span>
							<ul class="btns mt-5" style="float:right;">
								<li><a href="editar-anuncio.php?id="><span class="lnr lnr-pencil"></span> Editar</a></li>
								<li><a href="excluir-anuncio.php?id="><span class="lnr lnr-cross"></span> Excluir</a></li>
							</ul>
						</div>
					</div>
				
			</div>
			<div class="col-lg-4 sidebar">
				<div class="single-slidebar">
					<h4></h4>
					<ul class="cat-list">
						<li><a class="justify-content-between d-flex" href="category.html">
								<p>Total de Anuncios</p><span><span class="badge badge-danger"></span></span>
							</a></li>

						<li><a class="justify-content-between d-flex" href="perfil.php?id=<?php echo $_SESSION['cLogin']; ?>">
								<p class="mt-1">Meu perfil</p><span>

		
									<div class="thumbanuncio">
										<div class="panel-body">
										
												<div class="foto_item_anuncio">
													<img src="img/avata/<?php echo $fotosperf['url']; ?>" width="180" height="180" class="img-thumbnail circ" alt="">
												</div>
											
												<div class="foto_item_anuncio">
													<img src="img/avata/default.png" width="180" height="180" class="img-thumbnail circ" alt="">
												</div>
											
										</div>
									</div>
								</span>
							</a></li>
						<li><a class="justify-content-between d-flex" href="sair.php">
								<p>Sair</p><span></span>
							</a></li>

					</ul>
				</div>

				<div class="single-slidebar">
					<h4>Publicidade</h4>
					<div class="active-relatedjob-carusel">
						<div class="single-rated">
							<img class="img-fluid" src="img/r1.jpg" alt="">

						</div>
						<div class="single-rated">
							<img class="img-fluid" src="img/r1.jpg" alt="">

						</div>
						<div class="single-rated">
							<img class="img-fluid" src="img/r1.jpg" alt="">
						</div>
					</div>
				</div>

				<div class="single-slidebar">




				</div>
			</div>
		</div>
</section>
<!-- End post Area -->

<?php require 'pagesuser/footer.php'; ?>