<?php require 'pages/header-cliente.php'; ?>
<?php
if (empty($_SESSION['cLogin'])) {
	?>
	<script type="text/javascript">
		window.location.href = "login.php";
	</script>
	<?php
	exit;
}
?>
<!-- Start blog-posts Area -->
<section class="post-area mt-5">
	<div class="container">
		<h1>Meus Anuncios</h1>
		<?php
		require 'classes/qtdanuncios.class.php';
		require 'classes/usuarios.class.php';
		$u = new Usuarios();
		$a = new listAnunc();
		$listanuncios = $a->getLisAnuncios();
		$infocad = $a->getListaCad();
		$u->setUsuario($_SESSION['cLogin']);

		foreach ($listanuncios as $lisanuncios) :

			?>
		<?php endforeach; ?>
		<?php if ($u->temStatus('2')) : ?>
			<a href="add-anuncio.php" class="genric-btn default radius mt-5" style="border: 2px solid #eee;">Adicionar Anuncio</a>
		<?php else : ?>
			<a href="#" class="genric-btn default radius mt-5" onClick="swal('OPS!', 'Para adicionar anuncio é preciso efetuar o pagamento!', 'warning')" style="border: 2px solid #eee;">Adicionar Anuncio</a>
		<?php endif; ?>


		<div class="row justify-content-center d-flex mt-5">
			<div class="col-lg-8 post-list">
				<?php
				require 'classes/anuncios.class.php';
				require 'classes/cadastros.class.php';
				$a = new Anuncios();
				$anuncios = $a->getMeusAnuncios();
				$anucad = $a->getMeuscad();

				foreach ($anuncios as $anuncio) :
					?>

					<div class="thumb">
						<?php if (!empty($anuncio['url'])) : ?>
							<img src="img/anuncios/<?php echo $anuncio['url']; ?>" class="img-thumbnail" alt="">
						<?php else : ?>
							<img src="img/anuncios/default.jpg" class="img-thumbnail" alt="">
						<?php endif; ?>
					</div>
					<div class="single-post d-flex flex-row">

						<div class="details" style="margin-left:30px;">
							<div class="title d-flex flex-row justify-content-between">
								<div class="titles">
									<a href="single.html">
										<h4><?php echo $anuncio['titulo']; ?></h4>
									</a>
									<h6>Premium Labels Limited</h6>
								</div>

							</div>
							<p>
								<?php echo $anuncio['descricao']; ?>
							</p>
							<span class="badge badge-secondary" style="padding:4px; font-size:16px;">Tel: <?php echo $anuncio['telefone']; ?></span>
							<span class="badge badge-secondary" style="padding:4px; font-size:16px;">Caidade: <?php echo $anuncio['cidade']; ?></span>
							<span class="badge badge-secondary" style="padding:4px; font-size:16px;">Bairro: <?php echo $anuncio['bairro']; ?></span>
							<ul class="btns mt-5" style="float:right;">
								<li><a href="editar-anuncio.php?id=<?php echo $anuncio['id']; ?>"><span class="lnr lnr-pencil"></span> Editar</a></li>
								<li><a href="excluir-anuncio.php?id=<?php echo $anuncio['id']; ?>"><span class="lnr lnr-cross"></span> Excluir</a></li>
							</ul>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<div class="col-lg-4 sidebar">
				<div class="single-slidebar">
					<h4></h4>
					<ul class="cat-list">
						<li><a class="justify-content-between d-flex" href="category.html">
								<p>Total de Anuncios</p><span><span class="badge badge-danger"><?php echo count($listanuncios); ?></span></span>
							</a></li>

						<li><a class="justify-content-between d-flex" href="perfil.php?id=<?php echo $_SESSION['cLogin']; ?>">
								<p class="mt-1">Meu perfil</p><span>

									<?php

									$fotoperf = $u->getCadfoto();

									foreach ($fotoperf as $fotosperf) :
										?>
									<?php endforeach; ?>
									<div class="thumbanuncio">
										<div class="panel-body">
											<?php if (!empty($fotosperf['url'])) : ?>
												<div class="foto_item_anuncio">
													<img src="img/avata/<?php echo $fotosperf['url']; ?>" width="180" height="180" class="img-thumbnail circ" alt="">
												</div>
											<?php else : ?>
												<div class="foto_item_anuncio">
													<img src="img/avata/default.png" width="180" height="180" class="img-thumbnail circ" alt="">
												</div>
											<?php endif; ?>
										</div>
									</div>
								</span>
							</a></li>
						<li><a class="justify-content-between d-flex" href="sair.php">
								<p>Sair</p><span></span>
							</a></li>

					</ul>
				</div>

				<div class="single-slidebar">
					<h4>Publicidade</h4>
					<div class="active-relatedjob-carusel">
						<div class="single-rated">
							<img class="img-fluid" src="img/r1.jpg" alt="">

						</div>
						<div class="single-rated">
							<img class="img-fluid" src="img/r1.jpg" alt="">

						</div>
						<div class="single-rated">
							<img class="img-fluid" src="img/r1.jpg" alt="">
						</div>
					</div>
				</div>

				<div class="single-slidebar">




				</div>
			</div>
		</div>
</section>
<!-- End post Area -->

<?php require 'pages/footer.php'; ?>