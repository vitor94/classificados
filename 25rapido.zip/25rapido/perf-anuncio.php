<?php include("pages/header.php"); ?>
<?php

require 'classes/anuncios.class.php';
require 'classes/cadastros.class.php';
require 'classes/comentarios.class.php';
$a = new Anuncios();
$i = new infocad();
$c = new comentarios();

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = addslashes($_GET['id']);
}
$info = $a->getAnuncio($id);

if (isset($_POST['nome']) && !empty($_POST['nome']) == true) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $msg = $_POST['msg'];

    $c->addComent($nome, $email, $msg);
    ?>
    <script language="javascript">
        swal({
            icon: "success",
            title: "Comentario enviado com sucesso!",
            showConfirmButton: true,
            confirmButtonText: "Voltar",
            closeOnConfirm: false
        }).then(function(result) {
            window.location = "perf-anuncio.php?id=<?php echo $info['id']; ?>";
        })
    </script>
<?php } else { ?>

<?php
} ?>
<script>

function myFunction() {
  swal({
            icon: "success",
            title: "Comentario enviado com sucesso!",
            showConfirmButton: true,
            confirmButtonText: "Voltar",
            closeOnConfirm: false
        }).then(function(result) {
            window.location = "perf-anuncio.php?id=<?php echo $info['id']; ?>";
        })
}

</script>

<!-- start banner Area -->
<header class="banner-area relative" id="home">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="about-content col-lg-12">
                <h1 class="text-white">
                    <?php echo $info['titulo']; ?>
                </h1>
                <p class="text-white link-nav"><a href="index.html">Home </a> <span class="lnr lnr-arrow-right"></span> <a href="elements.html"> Elements</a></p>
            </div>
        </div>
    </div>
</header>
<!-- start banner Area -->
<!-- Start blog-posts Area -->
<section class="blog-posts-area section-gap">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 post-list blog-post-list">
                <div class="single-post">
                    <div class="thumb">

                        <?php foreach ($info['fotos'] as $foto) : endforeach; ?>


                        <?php if (!empty($foto['url'])) : ?>
                            <img src="img/anuncios/<?php echo $foto['url']; ?>" widht="255" height="176" alt="">
                        <?php else : ?>
                            <img src="img/anuncios/default.jpg" widht="255" height="176" alt="">
                        <?php endif; ?>
                    </div>
                    <ul class="tags">
                        <li><a href="#">Art</a></li>
                        <li><a href="#">Technology</a></li>
                        <li><a href="#">Fashion</a></li>
                    </ul>
                    <a href="#">
                        <h1>
                            <?php echo $info['titulo']; ?>
                        </h1>
                    </a>
                    <div class="content-wrap">
                        <p>
                            <?php echo $info['descricao']; ?>
                        </p>

                    </div>
                    <div class="bottom-meta">
                        <div class="user-details row align-items-center">
                            <div class="comment-wrap col-lg-6 col-sm-6">
                                <ul>
                                    <li><a href="#"><span class="lnr lnr-heart"></span> 4 likes</a></li>
                                    <li><a href="#"><span class="lnr lnr-bubble"></span> 06 Comments</a></li>
                                </ul>
                            </div>
                            <div class="social-wrap col-lg-6">
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                    <li><a href="#"><i class="fa fa-behance"></i></a></li>
                                </ul>

                            </div>
                        </div>
                    </div>

                    <!-- Start nav Area -->
                    <section class="nav-area pt-50 pb-100">
                        <div class="container">
                            <div class="row justify-content-between">
                                <div class="col-sm-6 nav-left justify-content-start d-flex">
                                    <div class="thumb">
                                        <img src="img/blog/prev.jpg" alt="">
                                    </div>
                                    <div class="post-details">
                                        <p>Prev Post</p>
                                        <h4 class="text-uppercase"><a href="#">A Discount Toner</a></h4>
                                    </div>
                                </div>
                                <div class="col-sm-6 nav-right justify-content-end d-flex">
                                    <div class="post-details">
                                        <p>Prev Post</p>
                                        <h4 class="text-uppercase"><a href="#">A Discount Toner</a></h4>
                                    </div>
                                    <div class="thumb">
                                        <img src="img/blog/next.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- End nav Area -->

                    <!-- Start comment-sec Area -->
                    <section class="comment-sec-area pt-80 pb-80">
                        <div class="container">
                            <div class="row flex-column">
                                <h5 class="text-uppercase pb-80">05 Comments</h5>
                                <br>

                                <?php
                                $sql = "SELECT * FROM comentarios ORDER BY data_msg DESC";
                                $sql = $pdo->query($sql);
                                if ($sql->rowCount() > 0) {
                                    foreach ($sql->fetchAll() as $comentario) : ?>

                                        <div class="comment-list">
                                            <div class="single-comment justify-content-between d-flex">
                                                <div class="user justify-content-between d-flex">
                                                    <div class="thumb">
                                                        <img src="img/blog/c5.jpg" alt="">
                                                    </div>
                                                    <div class="desc">
                                                        <h5><a href="#"><?php echo $comentario['nome']; ?></a></h5>
                                                        <p class="date">December 4, 2017 at 3:12 pm </p>
                                                        <p class="comment">
                                                            <?php echo $comentario['msg']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="reply-btn">
                                                    <a href="" class="btn-reply text-uppercase">reply</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach;
                                } else { ?>
                                    <h6>Não á comentarios.</h6>
                                <?php } ?>



                            </div>
                        </div>
                    </section>
                    <!-- End comment-sec Area -->

                    <!-- Start commentform Area -->
                    <section class="commentform-area pt-80">
                        <div class="container">
                            <h3 class="mt-0">Deixe seu comentario</h3>
                            <p class="mt-3">Como foi a sua experiência ?</p>
                            <a style='text-decoration: none;' href="votar.php?id=<?php echo $info['id']; ?>&voto=1">
                            <?php if (isset($_SESSION["cLoginUser"]) && !empty($_SESSION["cLoginUser"])): ?>
                                <?php
                                if (ceil($info['media']) >= 1) {
                                    ?>
                                    <img src="img/star.png" height="20" />
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>

                            <a style='text-decoration: none;' href="votar.php?id=<?php echo $info['id']; ?>&voto=2">
                                <?php
                                if (ceil($info['media']) >= 2) {
                                    ?>
                                    <img src="img/star.png" height="20" />
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <a style='text-decoration: none;' href="votar.php?id=<?php echo $info['id']; ?>&voto=3">
                                <?php
                                if (ceil($info['media']) >= 3) {
                                    ?>
                                    <img src="img/star.png" height="20" />
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <a style='text-decoration: none;' href="votar.php?id=<?php echo $info['id']; ?>&voto=4">
                                <?php
                                if (ceil($info['media']) >= 4) {
                                    ?>
                                    <img src="img/star.png" height="20" />
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <a style='text-decoration: none;' href="votar.php?id=<?php echo $info['id']; ?>&voto=5">
                                <?php
                                if (ceil($info['media']) >= 5) {
                                    ?>
                                    <img src="img/star.png" height="20" />
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <?php echo substr($info['media'], 0, 3), '', ''; ?> / 5

                                <?php else: ?>  
                                <a style='text-decoration: none;' href="#" onclick="myFunction()">            
                                <?php
                                if (ceil($info['media']) >= 1) {
                                    ?>
                                    <img src="img/star.png" height="20"/>
                                    
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>

                            <a style='text-decoration: none;' href="#" onclick="swal('OPS!', 'É preciso tá logado!', 'warning')">
                                <?php
                                if (ceil($info['media']) >= 2) {
                                    ?>
                                    <a href="" class="teste"><img src="img/star.png" height="20" /></a>
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <a style='text-decoration: none;' href="#" onclick="swal('OPS!', 'É preciso tá logado!', 'warning')">
                                <?php
                                if (ceil($info['media']) >= 3) {
                                    ?>
                                    <a href="" class="teste"><img src="img/star.png" height="20" /></a>
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <a style='text-decoration: none;' href="#" onclick="swal('OPS!', 'É preciso tá logado!', 'warning')">
                                <?php
                                if (ceil($info['media']) >= 4) {
                                    ?>
                                    <a href="" class="teste"><img src="img/star.png" height="20" /></a>
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <a style='text-decoration: none;' href="#" onclick="swal('OPS!', 'É preciso tá logado!', 'warning')">
                                <?php
                                if (ceil($info['media']) >= 5) {
                                    ?>
                                    <a href="" class="teste"><img src="img/star.png" height="20" /></a>
                                <?php } else { ?>
                                    <img src="img/star0.png" height="20" />
                                <?php } ?>
                            </a>
                            <?php echo substr($info['media'], 0, 3), '', ''; ?> / 5
                                    
                                <?php endif; ?>
                            <div class="row flex-row d-flex">
                                <div class="col-lg-12 col-md-">
                                    <form method="POST" id="#form-anuncio" class="form-area contact-form text-left mt-4">
                                        <div class="row">
                                            <div class="col-lg-12 form-group">
                                                <input name="nome" placeholder="Nome" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your name'" class="common-input mb-20 form-control" required="" type="text">

                                                <input name="email" placeholder="E-mail" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" class="common-input mb-20 form-control" required="" type="email">
                                                <label for="">
                                                    <h6>Deixe sua avaliação</h6>
                                                </label>
                                                <textarea class="common-textarea mt-10 form-control" name="msg" placeholder="Mensagem" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Messege'" required=""></textarea>
                                                <?php if (isset($_SESSION["cLoginUser"]) && !empty($_SESSION["cLoginUser"])) { ?>
                                                    <button type="submit" class="primary-btn mt-20 text-white" style="float: right;">Avaliar</button>
                                                <?php } elseif (isset($_SESSION["cLogin"]) && !empty($_SESSION["cLogin"])) { ?>
                                                    <a href="#" onclick="swal('OPS!', 'O profissional não pode comentar!', 'warning')" class="primary-btn mt-20 text-white" style="float: right;">Avaliar</a>
                                                <?php } else { ?>
                                                    <a href="#" onclick="swal('OPS!', 'É preciso tá logado!', 'warning')" class="primary-btn mt-20 text-white" style="float: right;">Avaliar</a>
                                                <?php } ?>
                                                <div class="mt-20 alert-msg" style="text-align: left;"></div>
                                            </div>
                                        </div>

                                    </form>

                                </div>

                            </div>
                        </div>
                    </section>
                    <!-- End commentform Area -->


                </div>
            </div>
            <div class="col-lg-4 sidebar">
                <div class="single-widget search-widget">
                    <form class="example" action="#" style="margin:auto;max-width:300px">
                        <input type="text" placeholder="Search Posts" name="search2">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>

                <div class="single-widget protfolio-widget">
                    <img src="img/blog/user2.jpg" alt="">
                    <a href="#">
                        <h4>Adele Gonzalez</h4>
                    </a>
                    <p>
                        MCSE boot camps have its supporters and
                        its detractors. Some people do not understand why you should have to spend money
                        on boot camp when you can get.
                    </p>
                    <ul>
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li><a href="#"><i class="fa fa-behance"></i></a></li>
                    </ul>
                </div>

                <div class="single-widget category-widget">
                    <h4 class="title">Post Categories</h4>
                    <ul>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Techlology</h6> <span>37</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Lifestyle</h6> <span>24</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Fashion</h6> <span>59</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Art</h6> <span>29</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Food</h6> <span>15</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Architecture</h6> <span>09</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Adventure</h6> <span>44</span>
                            </a></li>
                    </ul>
                </div>

                <div class="single-widget recent-posts-widget">
                    <h4 class="title">Recent Posts</h4>
                    <div class="blog-list ">
                        <div class="single-recent-post d-flex flex-row">
                            <div class="recent-thumb">
                                <img class="img-fluid" src="img/blog/r1.jpg" alt="">
                            </div>
                            <div class="recent-details">
                                <a href="blog-single.html">
                                    <h4>
                                        Home Audio Recording
                                        For Everyone
                                    </h4>
                                </a>
                                <p>
                                    02 hours ago
                                </p>
                            </div>
                        </div>
                        <div class="single-recent-post d-flex flex-row">
                            <div class="recent-thumb">
                                <img class="img-fluid" src="img/blog/r2.jpg" alt="">
                            </div>
                            <div class="recent-details">
                                <a href="blog-single.html">
                                    <h4>
                                        Home Audio Recording
                                        For Everyone
                                    </h4>
                                </a>
                                <p>
                                    02 hours ago
                                </p>
                            </div>
                        </div>
                        <div class="single-recent-post d-flex flex-row">
                            <div class="recent-thumb">
                                <img class="img-fluid" src="img/blog/r3.jpg" alt="">
                            </div>
                            <div class="recent-details">
                                <a href="blog-single.html">
                                    <h4>
                                        Home Audio Recording
                                        For Everyone
                                    </h4>
                                </a>
                                <p>
                                    02 hours ago
                                </p>
                            </div>
                        </div>
                        <div class="single-recent-post d-flex flex-row">
                            <div class="recent-thumb">
                                <img class="img-fluid" src="img/blog/r4.jpg" alt="">
                            </div>
                            <div class="recent-details">
                                <a href="blog-single.html">
                                    <h4>
                                        Home Audio Recording
                                        For Everyone
                                    </h4>
                                </a>
                                <p>
                                    02 hours ago
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="single-widget category-widget">
                    <h4 class="title">Post Archive</h4>
                    <ul>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Dec '17</h6> <span>37</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Nov '17</h6> <span>24</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Oct '17</h6> <span>59</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Sep '17</h6> <span>29</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Aug '17</h6> <span>15</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Jul '17</h6> <span>09</span>
                            </a></li>
                        <li><a href="#" class="justify-content-between align-items-center d-flex">
                                <h6>Jun '17</h6> <span>44</span>
                            </a></li>
                    </ul>
                </div>

                <div class="single-widget tags-widget">
                    <h4 class="title">Tag Clouds</h4>
                    <ul>
                        <li><a href="#">Lifestyle</a></li>
                        <li><a href="#">Art</a></li>
                        <li><a href="#">Adventure</a></li>
                        <li><a href="#">Food</a></li>
                        <li><a href="#">Techlology</a></li>
                        <li><a href="#">Fashion</a></li>
                        <li><a href="#">Architecture</a></li>
                        <li><a href="#">Food</a></li>
                        <li><a href="#">Technology</a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</section>
<!-- End blog-posts Area -->

<?php include("pages/footer.php"); ?>